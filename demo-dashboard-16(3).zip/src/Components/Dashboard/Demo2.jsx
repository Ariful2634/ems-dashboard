

const Demo2 = () => {
    return (
        <div>
            <h2>Demo 2 is here</h2>
        </div>
    );
};

export default Demo2;