import Login from "../Login/Login";



const Home = () => {
    return (
        <div>
            <Login></Login>
        </div>
    );
};

export default Home;