

const SelectedYearData = () => {
    return (
        <div>
            <h2>hlw</h2>
        </div>
    );
};

export default SelectedYearData;