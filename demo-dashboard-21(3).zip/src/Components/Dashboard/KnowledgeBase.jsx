

const KnowledgeBase = () => {
    return (
        <div>
            <h2>Knowledge</h2>
        </div>
    );
};

export default KnowledgeBase;