
// import Checkbox from './Checkbox';
import SelectedDateData from './SelectedDateData';


const Analysis_Pro = () => {
    return (
        <div>
          <SelectedDateData/>
        </div>
    );
};

export default Analysis_Pro;